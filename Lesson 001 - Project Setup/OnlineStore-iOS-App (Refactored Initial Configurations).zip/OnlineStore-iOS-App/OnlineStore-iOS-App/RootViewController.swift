//
//  RootViewController.swift
//  OnlineStore-iOS-App
//
//  Created by Pavel Palancica on 8/14/22.
//

import UIKit

class RootViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        view.backgroundColor = .lightGray
    }
}
